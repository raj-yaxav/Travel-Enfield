import { chromium } from 'playwright-core';
import { mkdir } from 'node:fs/promises';
import path from 'node:path';

const chrome = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const targetUrl = process.env.CAPTURE_URL || 'https://www.captureatrip.com/';
const captureName = process.env.CAPTURE_NAME || 'captureatrip-live';
const outDir = path.resolve('screenshots', captureName);
await mkdir(outDir, { recursive: true });
const browser = await chromium.launch({ executablePath: chrome, headless: true });

async function capture(name, viewport, maxShots) {
  const page = await browser.newPage({ viewport, deviceScaleFactor: 1 });
  await page.goto(targetUrl, { waitUntil: 'domcontentloaded', timeout: 90000 });
  await page.waitForTimeout(5000);
  const height = await page.evaluate(() => document.documentElement.scrollHeight);
  const step = Math.max(1, Math.floor((height - viewport.height) / Math.max(1, maxShots - 1)));
  for (let index = 0; index < maxShots; index += 1) {
    const y = Math.min(index * step, height - viewport.height);
    await page.evaluate(scrollY => window.scrollTo({ top: scrollY, behavior: 'instant' }), y);
    await page.waitForTimeout(500);
    await page.screenshot({ path: path.join(outDir, `${name}-${String(index + 1).padStart(2, '0')}-y${y}.png`), fullPage: false });
  }
  await page.close();
  return { name, height, shots: maxShots, viewport };
}

const results = [];
results.push(await capture('desktop', { width: 1440, height: 900 }, 14));
results.push(await capture('mobile', { width: 390, height: 844 }, 12));
console.log(JSON.stringify(results, null, 2));
await browser.close();
